$(document).ready(function () {
    // Handle form submission (for both new entries and updates)
    $("form").submit(function (e) {
        e.preventDefault(); // Prevent default form submission

        var firstName = $("input[name='firstname']").val();
        var lastName = $("input[name='lastname']").val();
        var phone = $("input[name='phone']").val();
        var email = $("input[name='email']").val();
        var gender = $("input[name='gender']:checked").val();
        var country = $("#country").val();

        var data = {
            FirstName: firstName,
            LastName: lastName,
            PhoneNumber: phone,
            Email: email,
            Gender: gender,
            Country: country
        };

        var id = $(this).data('id');  
        if (id) {
            
            $.ajax({
                url: `https://localhost:7040/api/Details/UpdateData/${id}`,
                type: 'PUT',
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function (response) {
                    alert(response.message);
                    window.location.reload(); 
                },
                error: function (xhr, status, error) {
                    alert("Error updating data");
                }
            });
        } else {
        
            $.ajax({
                url: 'https://localhost:7040/api/Details/SaveData',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(data),
                success: function (response) {
                    alert(response.message);
                    window.location.reload(); 
                },
                error: function (xhr, status, error) {
                    alert("Error saving data");
                }
            });
        }
    });

    $.get("https://localhost:7040/api/Details/GetData", function (data, status) {
        if (data && Array.isArray(data)) {
            data.forEach(function (item) {
                var newRow = "<tr>" +
                    "<td>" + item.firstName + "</td>" +
                    "<td>" + item.lastName + "</td>" +
                    "<td>" + item.phoneNumber + "</td>" +
                    "<td>" + item.email + "</td>" +
                    "<td>" + item.gender + "</td>" +
                    "<td>" + item.country + "</td>" +
                    "<td><button class='delete-btn' data-id='" + item.id + "'>Delete</button></td>" +
                    "<td><button class='update-btn' data-id='" + item.id + "'>Update</button></td>" +
                    "</tr>";
                $("#data-table tbody").append(newRow); 
            });
        } else {
            console.error("Error: Data is not in expected format or request failed.");
        }
    });

    $(document).on("click", ".delete-btn", function () {
        var id = $(this).data("id");

        $.ajax({
            url: `https://localhost:7040/api/Details/DeleteData/${id}`,
            type: 'DELETE',
            success: function (response) {
                alert("Record deleted successfully");
                window.location.reload(); 
            },
            error: function (xhr, status, error) {
                alert("Error deleting the record.");
            }
        });
    });


    $(document).on('click', '.update-btn', function () {
    var id = $(this).data('id'); 
  
    $.ajax({
        url: `https://localhost:7040/api/Details/GetDetaialById/${id}`,
        type: 'GET',
        success: function (data) {
           console.log(data)
            $("input[name='firstname']").val(data.firstName);
            $("input[name='lastname']").val(data.lastName);
            $("input[name='phone']").val(data.phoneNumber);
            $("input[name='email']").val(data.email);
            $("input[name='gender'][value='" + data.gender + "']").prop("checked", true);
            $("#country").val(data.country);

           
            $("form").data('id', id);  
            $("#submit").text('Update'); 
        },
        error: function (xhr, status, error) {
            alert("Error fetching data.");
        }
    });
});

});
